import json
import boto3
import os

# Initialize Boto3 clients
# Use the environment variables from Terraform
dynamodb = boto3.resource('dynamodb')
menu_table = dynamodb.Table(os.environ['MENU_TABLE_NAME'])
orders_table = dynamodb.Table(os.environ['ORDERS_TABLE_NAME'])

# Bedrock client must be initialized with the specific region
bedrock_client = boto3.client('bedrock-runtime', region_name=os.environ['BEDROCK_REGION'])

def lambda_handler(event, context):
    """
    Main handler that Lex invokes.
    Routes the request based on the intent name.
    """
    intent_name = event['sessionState']['intent']['name']

    if intent_name == 'OrderFood':
        return handle_order_food(event)
    elif intent_name == 'AskRecommendation':
        # You would create this intent in Lex later
        return handle_recommendation(event)
    else:
        # A fallback for unknown intents
        return close_dialog(event, 'Failed', {'contentType': 'PlainText', 'content': "Sorry, I don't know how to handle that."})

def handle_order_food(event):
    """
    Handles the logic for the OrderFood intent.
    - Validates slots
    - Saves order to DynamoDB
    """
    # 1. Extract slots from the Lex event
    slots = event['sessionState']['intent']['slots']
    item = slots.get('ItemName', {}).get('value', {}).get('interpretedValue')
    quantity = slots.get('Quantity', {}).get('value', {}).get('interpretedValue')

    # 2. Add your business logic here
    # - Check if the item exists in the Menu table
    # - If it does, save the order to the Orders table
    print(f"Received order for {quantity} of {item}")

    # 3. Return a response to Lex to close the conversation
    message = f"Thanks! I've placed your order for {quantity} of {item}."
    return close_dialog(event, 'Fulfilled', {'contentType': 'PlainText', 'content': message})

def close_dialog(event, fulfillment_state, message):
    """
    Formats the response that is sent back to Amazon Lex.
    """
    response = {
        'sessionState': {
            'dialogAction': {
                'type': 'Close'
            },
            'intent': event['sessionState']['intent']
        },
        'messages': [message]
    }
    response['sessionState']['intent']['state'] = fulfillment_state
    return response